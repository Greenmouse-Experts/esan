<?php session_start();?>
<?php
header('Location:vacancy.php');