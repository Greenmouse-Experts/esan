<?php session_start();?>
<?php
header('Location:createmessage.php');
