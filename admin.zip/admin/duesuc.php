?php session_start();?>
<?php
header('Location:duespayment.php');
