<?php session_start();?>
<?php
header('Location:message.php');
